﻿/*                 _       _           
                 | |     | |          
  _ __   ___   __| |_   _| |_   _ ___ 
 | '_ \ / _ \ / _` | | | | | | | / __|
 | | | | (_) | (_| | |_| | | |_| \__ \
 |_| |_|\___/ \__,_|\__,_|_|\__,_|___/
 @ewave open source | ©Roi ben haim  ®2016    
 */
  
  
var express = require('express');
var router = express.Router();
var util = require('util');
var fs = require("fs-extra");
var path = require('path');
 
 
 



router.get("/folders", function (req, res) {
    var parent_path = req.query.path;
    
    
    try {
        fs.statSync(path);
    }
    catch (e) {
        namefilter = path.substring(path.lastIndexOf("\\"));
        path = path.substring(0, path.lastIndexOf("\\"));
    }
    fs.readdir(path, function (err, items) {
        if (err !== null) {
            //try folder search
            return res.json([]);
        }
        if (path.lastIndexOf("\\") == path.length)
            path = path.substring(0, path.lastIndexOf("\\"));
        
        for (var i = 0; i < items.length; i++) {
            var file = path + '\\' + items[i];
            try {
                var stats = fs.statSync(file);
                if (stats.isDirectory()) {
                    if (namefilter !== "") {
                        if (file.toLocaleLowerCase().indexOf(namefilter) > -1)
                            oitems.push({ name: file });
                    }
                    else {
                        oitems.push({ name: file });
                    }
                }
            }
            catch (e) {
            }
        }
        res.json(oitems);
    });
    

    
});








module.exports = router;



