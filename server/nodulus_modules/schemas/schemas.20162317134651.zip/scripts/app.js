﻿
// setTimeout(function () {
//     nodulus.register(['schemaForm']);
//      
//     
//     var deps = {
//         "dependencies": [ 
//             "bootstrap-decorator.min.js",
//             "schem-form-definitions.js",
//             "angular-schema-form-dynamic-select.js"
//         ]
//     }
//     
//     for (var i = 0; i < deps.dependencies.length; i++) {
//         
//         var script = document.createElement('script');
//         script.type = 'text/javascript';
//         script.async = false;
//         script.src = "modules/schemas/scripts/" + deps.dependencies[i];
//         document.getElementsByTagName('head')[0].appendChild(script);
// 
//     }
// 
// }, 100)





