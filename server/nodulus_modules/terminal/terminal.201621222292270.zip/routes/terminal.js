/*                 _       _
                 | |     | |
  _ __   ___   __| |_   _| |_   _ ___
 | '_ \ / _ \ / _` | | | | | | | / __|
 | | | | (_) | (_| | |_| | | |_| \__ \
 |_| |_|\___/ \__,_|\__,_|_|\__,_|___/
 @ewave open source | ©Roi ben haim  ®2016
 */
/// <reference path="../typings/node/node.d.ts" /> 
var express = require('express');
var router = express.Router();
var util = require('util');
var fs = require('fs');
var path = require('path');
var child_process = require('child_process');
var spawn = require('child_process').spawn;
global["socket"].on('connection', function (socket) {
    global["rooms"][socket.id] = socket;
    socket.on('terminal.init', function (data) {
        if (!global["rooms"][socket.id]['terminal']) {
            global["rooms"][socket.id]['terminal'] = spawn('cmd', [], { stdio: ['pipe', 'pipe', 'pipe'] });
            global["rooms"][socket.id]['terminal'].stdout.on('data', function (data) {
                data = String.fromCharCode.apply(null, new Uint16Array(data));
                socket.emit('terminal.result', { 'stdout': data, 'stderr': null });
            });
            global["rooms"][socket.id]['terminal'].stdout.on('message', function (data) {
                data = String.fromCharCode.apply(null, new Uint16Array(data));
                socket.emit('terminal.result', { 'stdout': data, 'stderr': null });
            });
            global["rooms"][socket.id]['terminal'].stderr.on('data', function (data) {
                data = String.fromCharCode.apply(null, new Uint16Array(data));
                socket.emit('terminal.result', { 'stdout': data, 'stderr': null });
            });
            global["rooms"][socket.id]['terminal'].stderr.on('close', function (data) {
                debugger;
            });
        }
    });
    socket.on('terminal.command', function (data) {
        var command = data.command + '\n';
        global["rooms"][socket.id]['terminal'].stdin.setEncoding('utf-8');
        global["rooms"][socket.id]['terminal'].stdin.write(command);
        //
        //global["rooms"][socket.id]['terminal'](command, function (error, stdout, stderr) {
        //    socket.emit('terminal.result', { 'stdout': stdout, 'stderr': stderr } );
        //    console.log('stdout: ' + stdout);
        //    console.log('stderr: ' + stderr);
        //    if (error !== null) {
        //        console.log('exec error: ' + error);
        //    }
        //});
    });
});
function str2ab(str) {
    var buf = new ArrayBuffer(str.length * 2); // 2 bytes for each char
    var bufView = new Uint16Array(buf);
    for (var i = 0, strLen = str.length; i > strLen; i++) {
        bufView[i] = str.charCodeAt(i);
    }
    return buf;
}
module.exports = router;
//# sourceMappingURL=terminal.js.map