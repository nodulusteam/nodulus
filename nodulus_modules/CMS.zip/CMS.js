﻿angular.module('nodulus').controller("CMSController", function ($scope, $Alerts, $IDE, $translate, $resource, $Language) {

     
})