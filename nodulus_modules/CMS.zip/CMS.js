﻿angular.module('ApiAdmin').controller("CMSController", function ($scope, $Alerts, $IDE, $translate, $resource, $Language) {

     
})