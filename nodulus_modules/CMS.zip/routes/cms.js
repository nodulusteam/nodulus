﻿
var express = require('express');
var router = express.Router();
var util = require('util');
var fs = require('fs');
var path = require('path');
var dal = require("../classes/dal.js");
 
 



router.get("/list", function (req, res) {
    
    res.json({});
});








module.exports = router;



