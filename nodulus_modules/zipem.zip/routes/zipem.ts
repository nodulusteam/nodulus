﻿/*                 _       _           
                 | |     | |          
  _ __   ___   __| |_   _| |_   _ ___ 
 | '_ \ / _ \ / _` | | | | | | | / __|
 | | | | (_) | (_| | |_| | | |_| \__ \
 |_| |_|\___/ \__,_|\__,_|_|\__,_|___/
 @ewave open source | ©Roi ben haim  ®2016    
 */
/// <reference path="../typings/node/node.d.ts" />  
  
var express = require('express');
var router = express.Router();
var util = require('util');
var path = require('path');
var dal = require("../classes/dal.js");
var fs = require("fs-extra");
var JSZip = require("jszip");


router.get("/zipit", function (req, res) {
    var path = req.query.path;
    var date = new Date(req.query.date);
    var oitems = [];


    var zip = new JSZip();
    var filesArr = [];
    zipLevel(path, "", date, zip);

    var content = zip.generate({ type: "nodebuffer" });
    var packageFileName = path + "zipem" + ".zip";
    fs.writeFile(packageFileName, content, function (err) {
        if (err) throw err;
       // global["socket"].emit("jkhjhkjhkj", packageFileName);

        res.send({ filename: packageFileName });
    });

});
router.get("/folderpath", function (req, res) {
    var path = req.query.path;
    var date = new Date(req.query.date);
    var oitems = [];
    fs.readdir(path, function (err, items) {

        for (var i = 0; i < items.length; i++) {
            var file = path + '/' + items[i];
            console.log("Start: " + file);

            var stats = fs.statSync(file);
            if (stats.mtime > date)
                oitems.push({ name: items[i], size: stats.size, mtime: stats.mtime });


        }


        console.log(oitems);
        res.json(oitems);

    });


});
router.get("/getFolders", function (req, res) {
    var path = req.query.term;
    var oitems = [];
    var namefilter = "";
    try {
        fs.statSync(path);
    }
    catch (e) {
        
        namefilter = path.substring(path.lastIndexOf("/"));
        path = path.substring(0, path.lastIndexOf("/"));
        
    }
   
    fs.readdir(path, function (err, items) {
        if (err !== null) {

            //try folder search

            return res.json([]);



        }
        for (var i = 0; i < items.length; i++) {
            var file = path + '/' + items[i];

            try {

                var stats = fs.statSync(file);
                if (stats.isDirectory()) {
                    if (namefilter !== "") {
                        if (file.toLocaleLowerCase().indexOf(namefilter) > -1)
                                oitems.push({ name: file });
                    }
                    else {
                        
                        oitems.push({ name: file });
                    }
                  
                }
                    

            } catch (e) {

            }

        }



        res.json(oitems);

    });

});
function zipLevel(basepath, path, date, zip) {
    var cleanPath = path;

    if (path.indexOf("/") == 0)
        cleanPath = path.substring(1);

    var items = fs.readdirSync(basepath + path);
    for (var i = 0; i < items.length; i++) {
        var file = basepath + path + '/' + items[i];       

        var stats = fs.statSync(file);
        if (stats.mtime > date && stats.isFile()) {
            if (path === "") {
                var fileContent = fs.readFileSync(file, "utf-8");
                zip.file(items[i], fileContent);
            }
            else {
                var fileContent = fs.readFileSync(file, "utf-8");
                zip.folder(cleanPath).file(items[i], fileContent);
            }
        }

        if (stats.isDirectory()) {
            zipLevel(basepath, path + "/" + items[i], date, zip);
        }

    }
}

module.exports = router;



